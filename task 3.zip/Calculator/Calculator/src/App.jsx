import {useRef, useState} from "react";
import React from "react"
import './App.css'
function App()
{
const [input, setInput] = useState('');
const [result, setResult] = useState('');

const handleClick = (value) => {
  setInput(input + value);
};


const calculate = () => {
  try {
    setResult(eval(input).toString());
  } catch (error) {
    setResult('Error');
  }
};

  return(
  <div className="cal">
<h1 >Calculator</h1>
<br/>
{/* <input type="text" placeholder="Enter Value of X" ref={x}/>&nbsp; &nbsp;
<input type ="text" placeholder="Enter Value of Y" ref={y}/><br/><br/> */}
<input type="text" className="inp" value={input} placeholder="0" readOnly /><br/><br/>
<input type="text"className="inp" value={result} placeholder="Result" readOnly />

<div >
{/* <input className="btn1" type="text" /> */}
<button className="btn1" onClick={() => handleClick('1')}>1</button>
<button className="btn1" onClick={() => handleClick('2')}>2</button>
<button className="btn1"onClick={() => handleClick('3')}>3</button>
<button className="btn1"onClick={() => handleClick('/')}>/</button>
<button className="btn1"onClick={() => handleClick('4')}>4</button>
<button className="btn1" onClick={() => handleClick('5')}>5</button>
<button className="btn1" onClick={() => handleClick('6')}>6</button>
<button className="btn1" onClick={() => handleClick('*')}>*</button>
<button className="btn1" onClick={() => handleClick('7')}>7</button>
<button className="btn1" onClick={() => handleClick('8')}>8</button>
<button className="btn1" onClick={() => handleClick('9')}>9</button>
<button className="btn1" onClick={() => handleClick('-')}>-</button>
<button className="btn1"onClick={() => handleClick('%')}>%</button>
<button className="btn1" onClick={() => handleClick('0')}>0</button>
<button className="btn1"onClick={() => handleClick('+')}>+</button>
<button className="btn1" onClick={calculate}>=</button><br/><br/>
</div>
{/* <h1>Value of x is:{A}</h1>
<h1>Value of y is:{B}</h1>
<h1>Addition is is:{A+B}</h1> */}

  </div>
  )

}
export default App;